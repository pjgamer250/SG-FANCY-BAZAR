(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const app = $('#app');
  let S = { settings: {}, categories: [], products: [] };
  const inr = (n) => '₹' + Number(n).toLocaleString('en-IN');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pct = (p) => (p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0);
  const byId = (id) => S.products.find((p) => p.id === id);
  const catName = (id) => (S.categories.find((c) => c.id === id) || {}).name || '';

  /* ---------- cart ---------- */
  const loadCart = () => { try { return JSON.parse(localStorage.getItem('cart') || '[]'); } catch { return []; } };
  let cart = loadCart();
  const saveCart = () => { localStorage.setItem('cart', JSON.stringify(cart)); $('#cartCount').textContent = cart.reduce((s, l) => s + l.qty, 0); };
  function addToCart(id, qty = 1) {
    const p = byId(id); if (!p || p.stock < 1) return false;
    const l = cart.find((x) => x.id === id);
    if (l) l.qty = Math.min(p.stock, l.qty + qty); else cart.push({ id, qty: Math.min(p.stock, qty) });
    saveCart(); return true;
  }
  const cartLines = () => cart.map((l) => ({ ...l, p: byId(l.id) })).filter((l) => l.p && l.p.stock > 0).map((l) => ({ ...l, qty: Math.min(l.qty, l.p.stock) }));

  let toastT;
  function toast(html) {
    const t = $('#toast'); t.innerHTML = html; t.classList.add('on');
    clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
  }

  /* ---------- pieces ---------- */
  function hue(s) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; }
  function pic(p) {
    if (p.images && p.images[0]) return `<img src="${esc(p.images[0])}" alt="${esc(p.name)}" loading="lazy">`;
    const h = hue(p.name), ini = p.name.split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
    return `<div class="ph" style="background:linear-gradient(135deg,hsl(${h} 45% 38%),hsl(${(h + 40) % 360} 50% 52%))">${esc(ini)}</div>`;
  }
  function priceHtml(p) {
    const d = pct(p);
    return `<div class="price-row"><span class="price">${inr(p.price)}</span>${d ? `<span class="mrp">${inr(p.mrp)}</span><span class="off">${d}% off</span>` : ''}</div>`;
  }
  function card(p) {
    const d = pct(p), out = p.stock < 1;
    return `<article class="card">
      ${d >= 5 ? `<span class="tag">${d}% OFF</span>` : ''}
      <a class="pic" href="#/product/${p.id}" aria-label="${esc(p.name)}">${pic(p)}</a>
      <div class="info">
        <span class="brand-l">${esc(p.brand)}</span>
        <a class="pname" href="#/product/${p.id}">${esc(p.name)}</a>
        ${priceHtml(p)}
        ${p.offerText ? `<span class="offer-line">${esc(p.offerText)}</span>` : ''}
        ${out ? '<span class="oos">Out of stock</span>' : p.stock <= 5 ? `<span class="low">Only ${p.stock} left</span>` : ''}
      </div>
      <button class="add" data-add="${p.id}" ${out ? 'disabled' : ''}>${out ? 'Out of stock' : 'Add to cart'}</button>
    </article>`;
  }

  /* ---------- views ---------- */
  function home() {
    const s = S.settings, ps = S.products;
    const deals = [...ps].filter((p) => pct(p) > 0 && p.stock > 0).sort((a, b) => pct(b) - pct(a)).slice(0, 12);
    const feat = ps.filter((p) => p.featured && p.stock > 0).slice(0, 12);
    const banners = (s.banners || []);
    let h = '';
    if (banners.length) {
      h += `<section class="banners" aria-label="Offers"><div class="banner-track" id="bt">${banners.map((b) => `
        <a class="banner" href="${esc(b.link)}">${b.image ? `<img src="${esc(b.image)}" alt="">` : ''}
          <div class="txt"><h2>${esc(b.title)}</h2><p>${esc(b.subtitle)}</p><span class="btn">Shop now</span></div></a>`).join('')}</div>
        ${banners.length > 1 ? `<div class="bnav"><button data-b="-1" aria-label="Previous">‹</button><button data-b="1" aria-label="Next">›</button></div>` : ''}</section>`;
    }
    if (deals.length) h += `<section class="sec" style="margin-top:0"><div class="sec-h"><h2>Today's offers</h2><a href="#/offers">See all</a></div><div class="rail">${deals.map(card).join('')}</div></section>`;
    if (feat.length) h += `<section class="sec"><div class="sec-h"><h2>Featured picks</h2></div><div class="rail">${feat.map(card).join('')}</div></section>`;
    for (const c of S.categories) {
      const list = ps.filter((p) => p.category === c.id).slice(0, 8);
      if (list.length) h += `<section class="sec"><div class="sec-h"><h2>${esc(c.name)}</h2><a href="#/cat/${c.id}">View all</a></div><div class="grid">${list.slice(0, 6).map(card).join('')}</div></section>`;
    }
    if (!ps.length) h += `<div class="empty"><h2>No products yet</h2><p>Add your first product from the admin panel.</p></div>`;
    app.innerHTML = h;
  }

  function listing({ title, items, crumb }) {
    const brands = [...new Set(items.map((p) => p.brand).filter(Boolean))].sort();
    const maxP = Math.max(0, ...items.map((p) => p.price));
    app.innerHTML = `
      ${crumb ? `<div class="crumbs">${crumb}</div>` : ''}
      <div class="listing">
        <aside class="filters" id="filters">
          <h3>Price (₹)</h3>
          <div class="row"><input type="number" id="fmin" min="0" placeholder="Min" aria-label="Minimum price"><input type="number" id="fmax" min="0" placeholder="${maxP || 'Max'}" aria-label="Maximum price"></div>
          <hr><h3>Discount</h3>
          <label><input type="radio" name="fd" value="0" checked> Any</label>
          <label><input type="radio" name="fd" value="10"> 10% or more</label>
          <label><input type="radio" name="fd" value="25"> 25% or more</label>
          <label><input type="radio" name="fd" value="40"> 40% or more</label>
          <hr><label><input type="checkbox" id="fstock"> In stock only</label>
          ${brands.length > 1 ? `<hr><h3>Brand</h3>${brands.map((b) => `<label><input type="checkbox" class="fbrand" value="${esc(b)}"> ${esc(b)}</label>`).join('')}` : ''}
        </aside>
        <section>
          <div class="toolbar"><h1>${esc(title)}<small id="cnt"></small></h1>
            <div><button class="btn ghost fbtn" id="fbtn">Filters</button>
            <select id="sort" aria-label="Sort"><option value="rel">Featured</option><option value="plh">Price: low to high</option><option value="phl">Price: high to low</option><option value="disc">Biggest discount</option><option value="new">Newest</option></select></div>
          </div>
          <div class="grid" id="lgrid"></div>
        </section>
      </div>`;
    const run = () => {
      const min = +$('#fmin').value || 0, max = +$('#fmax').value || Infinity;
      const d = +document.querySelector('input[name=fd]:checked').value;
      const stock = $('#fstock').checked;
      const bs = [...document.querySelectorAll('.fbrand:checked')].map((x) => x.value);
      let r = items.filter((p) => p.price >= min && p.price <= max && pct(p) >= d && (!stock || p.stock > 0) && (!bs.length || bs.includes(p.brand)));
      const so = $('#sort').value;
      if (so === 'plh') r.sort((a, b) => a.price - b.price);
      else if (so === 'phl') r.sort((a, b) => b.price - a.price);
      else if (so === 'disc') r.sort((a, b) => pct(b) - pct(a));
      else if (so === 'new') r.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      else r.sort((a, b) => (b.featured - a.featured) || (b.stock > 0) - (a.stock > 0));
      $('#cnt').textContent = `${r.length} item${r.length === 1 ? '' : 's'}`;
      $('#lgrid').innerHTML = r.length ? r.map(card).join('') : `<div class="empty" style="grid-column:1/-1"><h2>No products match</h2><p>Try removing a filter.</p></div>`;
    };
    $('#filters').addEventListener('input', run);
    $('#sort').addEventListener('change', run);
    $('#fbtn').addEventListener('click', () => $('#filters').classList.toggle('open'));
    run();
  }

  function product(id) {
    const p = byId(id);
    if (!p) { app.innerHTML = `<div class="empty"><h2>Product not found</h2><p>It may have been removed.</p><a class="btn green" href="#/">Back to shop</a></div>`; return; }
    const d = pct(p), imgs = p.images || [];
    const out = p.stock < 1;
    app.innerHTML = `
      <div class="crumbs"><a href="#/">Home</a> / <a href="#/cat/${p.category}">${esc(catName(p.category))}</a> / ${esc(p.name)}</div>
      <div class="pdp">
        <div class="gallery">
          <div class="thumbs">${imgs.length > 1 ? imgs.map((u, i) => `<button class="${i ? '' : 'on'}" data-th="${esc(u)}" aria-label="Photo ${i + 1}"><img src="${esc(u)}" alt=""></button>`).join('') : ''}</div>
          <div class="bigpic" id="big">${d >= 5 ? `<span class="tag">${d}% OFF</span>` : ''}${pic(p)}</div>
        </div>
        <div>
          <span class="brand-l">${esc(p.brand)}</span>
          <h1>${esc(p.name)}</h1>
          <div class="big-price"><span class="price">${inr(p.price)}</span>${d ? `<span class="mrp">${inr(p.mrp)}</span><span class="save">You save ${inr(p.mrp - p.price)} (${d}%)</span>` : ''}</div>
          <div class="msg" style="color:var(--ink-3)">Inclusive of all taxes</div>
          ${p.offerText ? `<div class="offerbox">🏷️ ${esc(p.offerText)}</div>` : ''}
          ${out ? '<div class="oos" style="font-size:16px">Out of stock</div>' : `<div class="${p.stock <= 5 ? 'low' : 'off'}" style="font-size:14px">${p.stock <= 5 ? `Only ${p.stock} left, order soon` : 'In stock'}</div>`}
          <div class="buy">
            <div class="qty"><button data-q="-1" aria-label="Decrease">−</button><span id="qv">1</span><button data-q="1" aria-label="Increase">+</button></div>
            <button class="btn green" id="addc" ${out ? 'disabled' : ''} style="flex:1;min-width:150px">Add to cart</button>
            <button class="btn" id="buyn" ${out ? 'disabled' : ''} style="flex:1;min-width:150px">Buy now</button>
          </div>
          ${p.highlights && p.highlights.length ? `<h3>Highlights</h3><ul>${p.highlights.map((h) => `<li>${esc(h)}</li>`).join('')}</ul>` : ''}
          ${p.description ? `<h3>About this product</h3><p class="desc">${esc(p.description)}</p>` : ''}
          <div class="assure"><span>✔ Genuine products</span><span>✔ Cash on delivery</span><span>✔ Easy support on WhatsApp</span></div>
        </div>
      </div>`;
    let q = 1;
    app.querySelectorAll('[data-q]').forEach((b) => b.addEventListener('click', () => { q = Math.max(1, Math.min(p.stock, q + +b.dataset.q)); $('#qv').textContent = q; }));
    app.querySelectorAll('[data-th]').forEach((b) => b.addEventListener('click', () => {
      app.querySelectorAll('[data-th]').forEach((x) => x.classList.remove('on')); b.classList.add('on');
      $('#big').innerHTML = `<img src="${esc(b.dataset.th)}" alt="${esc(p.name)}">`;
    }));
    $('#addc').addEventListener('click', () => { if (addToCart(p.id, q)) toast(`Added to cart <a href="#/cart">View cart</a>`); });
    $('#buyn').addEventListener('click', () => { if (addToCart(p.id, q)) location.hash = '#/cart'; });
  }

  let coupon = null; // {code, discount}
  function cartView() {
    const lines = cartLines();
    if (!lines.length) { app.innerHTML = `<div class="empty"><h2>Your cart is empty</h2><p>Add something you like and it will show up here.</p><a class="btn green" href="#/">Start shopping</a></div>`; return; }
    const s = S.settings;
    const subtotal = lines.reduce((t, l) => t + l.p.price * l.qty, 0);
    const mrpTotal = lines.reduce((t, l) => t + l.p.mrp * l.qty, 0);
    if (coupon && coupon.minChecked !== subtotal) coupon = null; // re-validate when cart changes
    const disc = coupon ? coupon.discount : 0;
    const delivery = subtotal - disc >= s.freeDeliveryAbove ? 0 : s.deliveryFee;
    const total = subtotal - disc + delivery;
    app.innerHTML = `
      <div class="cartpg">
        <section class="panel"><h2>Your cart (${lines.reduce((t, l) => t + l.qty, 0)} items)</h2>
          ${lines.map((l) => `<div class="line">
            <a class="pic" href="#/product/${l.p.id}">${pic(l.p)}</a>
            <div><a class="nm" href="#/product/${l.p.id}">${esc(l.p.name)}</a><div class="brand-l">${esc(l.p.brand)}</div>${priceHtml(l.p)}
              <button class="rm" data-rm="${l.p.id}">Remove</button></div>
            <div class="rhs"><div class="qty"><button data-cq="${l.p.id}" data-d="-1" aria-label="Decrease">−</button><span>${l.qty}</span><button data-cq="${l.p.id}" data-d="1" aria-label="Increase">+</button></div></div>
          </div>`).join('')}
        </section>
        <aside>
          <div class="panel sum"><h2>Order summary</h2>
            <div><span>Price (${lines.length} item${lines.length > 1 ? 's' : ''})</span><span>${inr(mrpTotal)}</span></div>
            ${mrpTotal > subtotal ? `<div class="disc"><span>Offer discount</span><span>− ${inr(mrpTotal - subtotal)}</span></div>` : ''}
            ${disc ? `<div class="disc"><span>Coupon ${esc(coupon.code)}</span><span>− ${inr(disc)}</span></div>` : ''}
            <div><span>Delivery</span><span>${delivery ? inr(delivery) : 'Free'}</span></div>
            <div class="total"><span>Total</span><span>${inr(total)}</span></div>
          </div>
          <div class="panel" style="margin-top:14px"><h2>Coupon code</h2>
            <div class="coupon"><input id="cc" placeholder="Enter code" value="${coupon ? esc(coupon.code) : ''}" aria-label="Coupon code"><button class="btn green" id="ca">Apply</button></div>
            <div class="msg ${coupon ? 'ok' : ''}" id="cm">${coupon ? `Coupon applied, you save ${inr(disc)}` : ''}</div>
          </div>
          <form class="panel" id="co" style="margin-top:14px"><h2>Delivery details</h2>
            <div class="field"><label for="cn">Full name</label><input id="cn" required maxlength="100" autocomplete="name"></div>
            <div class="field"><label for="cp">Phone number</label><input id="cp" required type="tel" inputmode="tel" maxlength="15" autocomplete="tel"></div>
            <div class="field"><label for="ca2">Delivery address</label><textarea id="ca2" required rows="3" maxlength="500" autocomplete="street-address"></textarea></div>
            <div class="msg err" id="em"></div>
            <button class="btn block" id="po">Place order · ${inr(total)}</button>
            <p class="msg" style="color:var(--ink-3);margin-top:8px">Pay on delivery. We will confirm your order by call or WhatsApp.</p>
          </form>
        </aside>
      </div>`;
    app.querySelectorAll('[data-rm]').forEach((b) => b.addEventListener('click', () => { cart = cart.filter((l) => l.id !== b.dataset.rm); saveCart(); cartView(); }));
    app.querySelectorAll('[data-cq]').forEach((b) => b.addEventListener('click', () => {
      const l = cart.find((x) => x.id === b.dataset.cq), p = byId(l.id);
      l.qty = Math.max(1, Math.min(p.stock, l.qty + +b.dataset.d)); saveCart(); cartView();
    }));
    $('#ca').addEventListener('click', async () => {
      const code = $('#cc').value.trim(); if (!code) return;
      const r = await fetch('/api/coupon/validate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code, subtotal }) });
      const j = await r.json();
      if (!r.ok) { coupon = null; $('#cm').className = 'msg err'; $('#cm').textContent = j.error; return; }
      coupon = { code: j.code, discount: j.discount, minChecked: subtotal }; cartView();
    });
    $('#co').addEventListener('submit', async (e) => {
      e.preventDefault(); const btn = $('#po'); btn.disabled = true; $('#em').textContent = '';
      try {
        const r = await fetch('/api/orders', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
          items: lines.map((l) => ({ id: l.id, qty: l.qty })), coupon: coupon && coupon.code,
          customer: { name: $('#cn').value, phone: $('#cp').value, address: $('#ca2').value } }) });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error);
        sessionStorage.setItem('lastOrder', JSON.stringify(j));
        cart = []; coupon = null; saveCart(); await refresh(); location.hash = '#/done/' + j.id;
      } catch (err) { $('#em').textContent = err.message; btn.disabled = false; }
    });
  }

  function done(id) {
    let o; try { o = JSON.parse(sessionStorage.getItem('lastOrder')); } catch {}
    if (!o || o.id !== id) { location.hash = '#/'; return; }
    const wa = (S.settings.whatsapp || '').replace(/\D/g, '');
    const text = encodeURIComponent(`Hi, I placed order ${o.id} (${inr(o.total)}). Name: ${o.customer.name}`);
    app.innerHTML = `<div class="done panel"><div class="ok">✓</div><h2 style="font-size:24px">Order placed</h2>
      <p style="margin:6px 0 14px;color:var(--ink-2)">Thank you, ${esc(o.customer.name)}. We will contact you on ${esc(o.customer.phone)} to confirm.</p>
      <div class="oid">${esc(o.id)}</div>
      <div style="margin:6px 0 20px;color:var(--ink-2)">Pay ${inr(o.total)} on delivery</div>
      ${wa ? `<a class="btn wa block" style="margin-bottom:10px" href="https://wa.me/${wa}?text=${text}" target="_blank" rel="noopener">Message us on WhatsApp</a>` : ''}
      <a class="btn green block" href="#/">Continue shopping</a></div>`;
  }

  /* ---------- router ---------- */
  function route() {
    const h = location.hash.replace(/^#\/?/, ''); const [a, ...r] = h.split('/'); const rest = decodeURIComponent(r.join('/'));
    document.querySelectorAll('#cats a').forEach((x) => x.classList.toggle('on', x.dataset.r === (a === 'cat' ? 'cat/' + rest : a || '')));
    window.scrollTo(0, 0);
    if (!a) return home();
    if (a === 'all') return listing({ title: 'All products', items: S.products, crumb: '<a href="#/">Home</a> / All products' });
    if (a === 'offers') return listing({ title: "Today's offers", items: S.products.filter((p) => pct(p) > 0), crumb: '<a href="#/">Home</a> / Offers' });
    if (a === 'cat') return listing({ title: catName(rest) || 'Category', items: S.products.filter((p) => p.category === rest), crumb: `<a href="#/">Home</a> / ${esc(catName(rest))}` });
    if (a === 'search') { const q = rest.toLowerCase(); const items = S.products.filter((p) => (p.name + ' ' + p.brand + ' ' + catName(p.category) + ' ' + p.description).toLowerCase().includes(q)); return listing({ title: `Results for “${rest}”`, items, crumb: '<a href="#/">Home</a> / Search' }); }
    if (a === 'product') return product(rest);
    if (a === 'cart') return cartView();
    if (a === 'done') return done(rest);
    home();
  }

  function chrome() {
    const s = S.settings;
    document.title = s.shopName + (s.tagline ? ' | ' + s.tagline : '');
    $('#brand').innerHTML = `<i>${esc((s.shopName || 'S')[0].toUpperCase())}</i><span>${esc(s.shopName)}</span>`;
    const an = $('#announce'); an.hidden = !s.announcement; an.textContent = s.announcement || '';
    $('#cats').innerHTML = `<a href="#/" data-r="">Home</a><a class="deal" href="#/offers" data-r="offers">Offers</a><a href="#/all" data-r="all">All</a>` +
      S.categories.map((c) => `<a href="#/cat/${c.id}" data-r="cat/${c.id}">${esc(c.name)}</a>`).join('');
    $('#foot').innerHTML = `<div><b>${esc(s.shopName)}</b>${esc(s.tagline || '')}</div>
      <div>${s.address ? esc(s.address) + '<br>' : ''}${s.phone ? 'Call: ' + esc(s.phone) : ''}</div>`;
  }

  async function refresh() {
    const r = await fetch('/api/store', { cache: 'no-store' }); S = await r.json(); chrome();
  }

  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-add]');
    if (a) { e.preventDefault(); if (addToCart(a.dataset.add)) toast('Added to cart <a href="#/cart">View cart</a>'); }
    const b = e.target.closest('[data-b]');
    if (b) { const t = $('#bt'); t.scrollBy({ left: +b.dataset.b * t.clientWidth, behavior: 'smooth' }); }
  });
  $('#searchForm').addEventListener('submit', (e) => { e.preventDefault(); const q = $('#q').value.trim(); if (q) location.hash = '#/search/' + encodeURIComponent(q); });
  window.addEventListener('hashchange', route);

  saveCart();
  refresh().then(route).catch(() => { app.innerHTML = '<div class="empty"><h2>Could not load the shop</h2><p>Check your connection and refresh.</p></div>'; });
})();
