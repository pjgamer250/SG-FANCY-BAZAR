(() => {
  const root = document.getElementById('root');
  const $ = (s, el = document) => el.querySelector(s);
  const inr = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let token = localStorage.getItem('adminToken') || '';
  let D = null, tab = 'dashboard', q = '';
  let toastT;
  const toast = (m) => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2400); };

  async function api(path, method = 'GET', body) {
    const r = await fetch('/api/admin' + path, {
      method, headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && path !== '/login') { token = ''; localStorage.removeItem('adminToken'); loginView(j.error); throw new Error(j.error); }
    if (!r.ok) throw new Error(j.error || 'Something went wrong');
    return j;
  }

  /* ---------- login ---------- */
  function loginView(msg = '') {
    root.innerHTML = `<div class="login"><form id="lf"><h1>Shop admin</h1><p>Sign in to manage products, offers and orders.</p>
      <div class="field"><label for="pw">Password</label><input id="pw" type="password" autocomplete="current-password" required autofocus></div>
      <div class="err" id="le">${esc(msg)}</div><button class="btn" style="width:100%">Sign in</button></form></div>`;
    $('#lf').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        const j = await api('/login', 'POST', { password: $('#pw').value });
        token = j.token; localStorage.setItem('adminToken', token); load();
      } catch (err) { $('#le').textContent = err.message; }
    });
  }

  async function load() {
    try { D = await api('/data'); } catch { return; }
    shell();
  }

  const TABS = [['dashboard', 'Dashboard'], ['products', 'Products'], ['offers', 'Offers'], ['coupons', 'Coupons'], ['orders', 'Orders'], ['settings', 'Settings']];
  function shell() {
    root.innerHTML = `<div class="shell"><nav class="side"><div class="logo">${esc(D.settings.shopName)} admin</div>
      ${TABS.map(([k, n]) => `<button class="nav ${tab === k ? 'on' : ''}" data-t="${k}">${n}${k === 'orders' && D.stats.newOrders ? `<b>${D.stats.newOrders}</b>` : ''}</button>`).join('')}
      <div class="sp"></div><a href="/" target="_blank">View shop</a><button class="out" id="out">Sign out</button></nav>
      <section class="main" id="main"></section></div>`;
    root.querySelectorAll('[data-t]').forEach((b) => b.addEventListener('click', () => { tab = b.dataset.t; q = ''; shell(); }));
    $('#out').addEventListener('click', () => { token = ''; localStorage.removeItem('adminToken'); loginView(); });
    ({ dashboard, products, offers, coupons, orders, settings })[tab]();
  }
  const main = () => $('#main');
  const catName = (id) => (D.categories.find((c) => c.id === id) || {}).name || id;
  const off = (p) => (p.mrp > p.price ? Math.round(((p.mrp - p.price) / p.mrp) * 100) : 0);
  const hue = (s) => { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) % 360; return h; };
  const thumb = (p) => p.images[0] ? `<img class="thumb" src="${esc(p.images[0])}" alt="">` : `<div class="thumb ph" style="background:hsl(${hue(p.name)} 45% 42%)">${esc(p.name[0] || '?')}</div>`;
  const run = async (fn, ok) => { try { await fn(); if (ok) toast(ok); await load(); } catch (e) { if (e.message) toast(e.message); } };

  /* ---------- dashboard ---------- */
  function dashboard() {
    const s = D.stats;
    main().innerHTML = `<div class="top"><h1>Dashboard</h1></div>
      <div class="stats">
        <div class="stat"><span>Revenue (excl. cancelled)</span><b>${inr(s.revenue)}</b></div>
        <div class="stat"><span>Orders</span><b>${s.orders}</b></div>
        <div class="stat"><span>New orders</span><b>${s.newOrders}</b></div>
        <div class="stat"><span>Products</span><b>${s.products}</b></div>
        <div class="stat"><span>Low or out of stock</span><b>${s.lowStock}</b></div>
      </div>
      <div class="panel"><h2>Latest orders</h2>${D.orders.length ? `<div class="tblwrap"><table class="tbl"><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr>
        ${D.orders.slice(0, 6).map((o) => `<tr><td><b>${o.id}</b></td><td>${esc(o.customer.name)}</td><td>${inr(o.total)}</td><td><span class="pill ${o.status}">${o.status}</span></td></tr>`).join('')}</table></div>` : '<p class="muted">No orders yet. They will show up here when customers check out.</p>'}</div>
      <div class="panel"><h2>Running low</h2>${D.products.filter((p) => p.stock <= 5).map((p) => `<div class="row" style="padding:4px 0"><b>${esc(p.name)}</b><span class="pill ${p.stock ? 'new' : 'cancelled'}">${p.stock ? p.stock + ' left' : 'Out of stock'}</span></div>`).join('') || '<p class="muted">All products are well stocked.</p>'}</div>`;
  }

  /* ---------- products ---------- */
  function products() {
    const list = D.products.filter((p) => (p.name + p.brand + catName(p.category)).toLowerCase().includes(q.toLowerCase()));
    main().innerHTML = `<div class="top"><h1>Products</h1><div class="row"><div class="field"><input id="ps" placeholder="Search products" value="${esc(q)}" aria-label="Search products"></div><button class="btn mango" id="np">Add product</button></div></div>
      ${list.length ? `<div class="tblwrap"><table class="tbl"><tr><th></th><th>Product</th><th>Category</th><th>MRP</th><th>Price</th><th>Offer</th><th>Stock</th><th>Status</th><th></th></tr>
      ${list.map((p) => `<tr><td>${thumb(p)}</td><td><b>${esc(p.name)}</b><div class="muted">${esc(p.brand)}</div></td><td>${esc(catName(p.category))}</td>
        <td class="muted">${inr(p.mrp)}</td><td><b>${inr(p.price)}</b></td><td>${off(p) ? off(p) + '% off' : '–'}</td><td>${p.stock}</td>
        <td><span class="pill ${p.active ? 'on' : 'off'}">${p.active ? 'Live' : 'Hidden'}</span></td>
        <td><div class="row"><button class="btn ghost sm" data-e="${p.id}">Edit</button><button class="btn danger sm" data-d="${p.id}">Delete</button></div></td></tr>`).join('')}</table></div>`
      : `<div class="panel"><p class="muted">${D.products.length ? 'No products match your search.' : 'No products yet. Click Add product to create the first one.'}</p></div>`}`;
    $('#ps').addEventListener('input', (e) => { q = e.target.value; products(); const i = $('#ps'); i.focus(); i.setSelectionRange(q.length, q.length); });
    $('#np').addEventListener('click', () => productForm());
    main().querySelectorAll('[data-e]').forEach((b) => b.addEventListener('click', () => productForm(D.products.find((p) => p.id === b.dataset.e))));
    main().querySelectorAll('[data-d]').forEach((b) => b.addEventListener('click', () => {
      const p = D.products.find((x) => x.id === b.dataset.d);
      if (confirm(`Delete "${p.name}"? This cannot be undone.`)) run(() => api('/products/' + p.id, 'DELETE'), 'Product deleted');
    }));
  }

  async function shrink(file) {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, 1400 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    const x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(bmp, 0, 0, c.width, c.height);
    return c.toDataURL('image/jpeg', 0.86);
  }
  async function uploadFile(file) {
    if (!/^image\//.test(file.type)) throw new Error('Choose an image file');
    const j = await api('/upload', 'POST', { data: await shrink(file) });
    return j.url;
  }

  function productForm(p) {
    const isNew = !p;
    p = p || { name: '', brand: '', category: D.categories[0]?.id || '', mrp: '', price: '', stock: 10, offerText: '', highlights: [], description: '', images: [], featured: false, active: true };
    let imgs = [...p.images];
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<form class="box"><h2>${isNew ? 'Add product' : 'Edit product'}</h2>
      <div class="form">
        <div class="field full"><label for="f_name">Product name</label><input id="f_name" required maxlength="200" value="${esc(p.name)}"></div>
        <div class="field"><label for="f_brand">Brand</label><input id="f_brand" maxlength="80" value="${esc(p.brand)}"></div>
        <div class="field"><label for="f_cat">Category</label><select id="f_cat">${D.categories.map((c) => `<option value="${c.id}" ${c.id === p.category ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
        <div class="field"><label for="f_mrp">MRP (₹)</label><input id="f_mrp" type="number" min="1" required value="${p.mrp}"></div>
        <div class="field"><label for="f_price">Selling price (₹)</label><input id="f_price" type="number" min="1" required value="${p.price}"></div>
        <div class="field"><label for="f_pct">Or discount %</label><input id="f_pct" type="number" min="0" max="90" placeholder="e.g. 25"><small>Fills the selling price from MRP</small></div>
        <div class="field"><label for="f_stock">Stock</label><input id="f_stock" type="number" min="0" required value="${p.stock}"></div>
        <div class="field full"><div class="preview" id="prev"></div></div>
        <div class="field full"><label for="f_offer">Offer tag (shown on the product)</label><input id="f_offer" maxlength="80" placeholder="e.g. Launch offer, Bank offer 5% off" value="${esc(p.offerText)}"></div>
        <div class="field full"><label>Photos</label><div class="imgs" id="imgs"></div><small>The first photo is the main one. Photos are resized automatically.</small></div>
        <div class="field full"><label for="f_hl">Highlights (one per line)</label><textarea id="f_hl" rows="3">${esc(p.highlights.join('\n'))}</textarea></div>
        <div class="field full"><label for="f_desc">Description</label><textarea id="f_desc" rows="4">${esc(p.description)}</textarea></div>
        <label class="check"><input type="checkbox" id="f_feat" ${p.featured ? 'checked' : ''}> Show in Featured picks</label>
        <label class="check"><input type="checkbox" id="f_act" ${p.active ? 'checked' : ''}> Visible in the shop</label>
      </div>
      <div class="err" id="ferr"></div>
      <div class="row" style="justify-content:flex-end"><button type="button" class="btn ghost" id="cx">Cancel</button><button class="btn" id="sv">${isNew ? 'Add product' : 'Save changes'}</button></div></form>`;
    document.body.appendChild(m);
    const f = (id) => $('#' + id, m);
    const prev = () => {
      const mrp = +f('f_mrp').value, pr = +f('f_price').value;
      f('prev').textContent = mrp && pr ? (pr <= mrp ? `Customers see ${inr(pr)}${mrp > pr ? ` (MRP ${inr(mrp)}, ${Math.round(((mrp - pr) / mrp) * 100)}% off)` : ''}` : 'Selling price cannot be higher than MRP') : 'Enter MRP and selling price to see the offer preview';
    };
    f('f_pct').addEventListener('input', () => { const mrp = +f('f_mrp').value, d = +f('f_pct').value; if (mrp && d >= 0) { f('f_price').value = Math.round(mrp * (1 - d / 100)); prev(); } });
    ['f_mrp', 'f_price'].forEach((i) => f(i).addEventListener('input', prev)); prev();
    const drawImgs = () => {
      f('imgs').innerHTML = imgs.map((u, i) => `<div class="im ${i ? '' : 'main'}"><img src="${esc(u)}" alt=""><button type="button" class="x" data-x="${i}" aria-label="Remove photo">×</button>${i ? `<button type="button" class="mk" data-mk="${i}">Make main</button>` : '<span class="tg" style="position:absolute;bottom:4px;left:4px;border-radius:7px;font-size:11px;font-weight:700;padding:2px 6px;background:var(--green);color:#fff">Main</span>'}</div>`).join('')
        + (imgs.length < 8 ? `<label class="add">+ Add photos<input type="file" id="fi" accept="image/*" multiple hidden></label>` : '');
      f('imgs').querySelectorAll('[data-x]').forEach((b) => b.addEventListener('click', () => { imgs.splice(+b.dataset.x, 1); drawImgs(); }));
      f('imgs').querySelectorAll('[data-mk]').forEach((b) => b.addEventListener('click', () => { const [u] = imgs.splice(+b.dataset.mk, 1); imgs.unshift(u); drawImgs(); }));
      const fi = f('fi');
      if (fi) fi.addEventListener('change', async () => {
        f('ferr').textContent = 'Uploading photos…';
        try { for (const file of [...fi.files].slice(0, 8 - imgs.length)) imgs.push(await uploadFile(file)); f('ferr').textContent = ''; }
        catch (e) { f('ferr').textContent = e.message; }
        drawImgs();
      });
    };
    drawImgs();
    f('cx').addEventListener('click', () => m.remove());
    m.addEventListener('mousedown', (e) => { if (e.target === m) m.remove(); });
    $('form', m).addEventListener('submit', async (e) => {
      e.preventDefault(); f('sv').disabled = true;
      const body = {
        name: f('f_name').value, brand: f('f_brand').value, category: f('f_cat').value, mrp: +f('f_mrp').value, price: +f('f_price').value,
        stock: +f('f_stock').value, offerText: f('f_offer').value, images: imgs, highlights: f('f_hl').value.split('\n'),
        description: f('f_desc').value, featured: f('f_feat').checked, active: f('f_act').checked,
      };
      if (body.price > body.mrp) { f('ferr').textContent = 'Selling price cannot be higher than MRP'; f('sv').disabled = false; return; }
      try { await api(isNew ? '/products' : '/products/' + p.id, isNew ? 'POST' : 'PUT', body); m.remove(); toast(isNew ? 'Product added' : 'Changes saved'); load(); }
      catch (err) { f('ferr').textContent = err.message; f('sv').disabled = false; }
    });
  }

  /* ---------- offers ---------- */
  function offers() {
    main().innerHTML = `<div class="top"><h1>Offers</h1></div>
      <div class="panel"><h2>Run a sale on a whole category</h2>
        <p class="muted" style="margin-bottom:14px">Sets the selling price of every product in the category to a percentage off its MRP. Use 0 to end a sale and go back to MRP. You can still change single products from the Products tab.</p>
        <div class="form">
          <div class="field"><label for="o_cat">Apply to</label><select id="o_cat"><option value="all">All products</option>${D.categories.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></div>
          <div class="field"><label for="o_pct">Discount % off MRP</label><input id="o_pct" type="number" min="0" max="90" value="20"></div>
          <div class="field"><label for="o_txt">Offer tag (optional)</label><input id="o_txt" maxlength="80" placeholder="e.g. Festive sale"></div>
        </div><div class="err" id="oe"></div><button class="btn mango" id="oa">Apply offer</button></div>
      <div class="panel"><h2>Products on offer now</h2>${D.products.filter((p) => off(p) > 0).map((p) => `<div class="row" style="padding:5px 0"><b>${esc(p.name)}</b><span class="pill on">${off(p)}% off</span><span class="muted">${inr(p.price)} (MRP ${inr(p.mrp)})</span>${p.offerText ? `<span class="pill">${esc(p.offerText)}</span>` : ''}</div>`).join('') || '<p class="muted">No offers running. Apply one above.</p>'}</div>`;
    $('#oa').addEventListener('click', async () => {
      const pc = +$('#o_pct').value, cat = $('#o_cat').value;
      if (!confirm(`Set ${pc}% off for ${cat === 'all' ? 'ALL products' : catName(cat)}?`)) return;
      try { const r = await api('/offers/apply', 'POST', { percent: pc, category: cat, offerText: $('#o_txt').value }); toast(`Updated ${r.updated} products`); load(); }
      catch (e) { $('#oe').textContent = e.message; }
    });
  }

  /* ---------- coupons ---------- */
  function coupons() {
    main().innerHTML = `<div class="top"><h1>Coupons</h1></div>
      <div class="panel"><h2>Create a coupon</h2><form id="cf"><div class="form">
        <div class="field"><label for="c_code">Code</label><input id="c_code" required maxlength="40" placeholder="SAVE20" style="text-transform:uppercase"></div>
        <div class="field"><label for="c_type">Type</label><select id="c_type"><option value="percent">Percent off</option><option value="flat">Flat ₹ off</option></select></div>
        <div class="field"><label for="c_val">Value</label><input id="c_val" type="number" min="1" required></div>
        <div class="field"><label for="c_min">Minimum order (₹)</label><input id="c_min" type="number" min="0" value="0"></div>
        <div class="field"><label for="c_max">Max discount (₹, percent only)</label><input id="c_max" type="number" min="0" value="0"><small>0 means no limit</small></div>
        <div class="field"><label for="c_exp">Expires on</label><input id="c_exp" type="date"><small>Leave empty for no expiry</small></div>
        <div class="field"><label for="c_lim">Total uses allowed</label><input id="c_lim" type="number" min="0" value="0"><small>0 means unlimited</small></div>
      </div><div class="err" id="ce"></div><button class="btn mango">Create coupon</button></form></div>
      ${D.coupons.length ? `<div class="tblwrap"><table class="tbl"><tr><th>Code</th><th>Discount</th><th>Min order</th><th>Expiry</th><th>Used</th><th>Status</th><th></th></tr>
      ${D.coupons.map((c) => `<tr><td><b>${esc(c.code)}</b></td><td>${c.type === 'percent' ? c.value + '%' + (c.maxDiscount ? ` (max ${inr(c.maxDiscount)})` : '') : inr(c.value)}</td><td>${c.minOrder ? inr(c.minOrder) : '–'}</td><td>${c.expiry || 'None'}</td><td>${c.used}${c.usageLimit ? ' / ' + c.usageLimit : ''}</td>
        <td><span class="pill ${c.active ? 'on' : 'off'}">${c.active ? 'Active' : 'Paused'}</span></td>
        <td><div class="row"><button class="btn ghost sm" data-tg="${esc(c.code)}">${c.active ? 'Pause' : 'Activate'}</button><button class="btn danger sm" data-dc="${esc(c.code)}">Delete</button></div></td></tr>`).join('')}</table></div>` : '<div class="panel"><p class="muted">No coupons yet.</p></div>'}`;
    $('#cf').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await api('/coupons', 'POST', { code: $('#c_code').value, type: $('#c_type').value, value: +$('#c_val').value, minOrder: +$('#c_min').value, maxDiscount: +$('#c_max').value, expiry: $('#c_exp').value, usageLimit: +$('#c_lim').value });
        toast('Coupon created'); load();
      } catch (err) { $('#ce').textContent = err.message; }
    });
    main().querySelectorAll('[data-tg]').forEach((b) => b.addEventListener('click', () => { const c = D.coupons.find((x) => x.code === b.dataset.tg); run(() => api('/coupons/' + c.code, 'PUT', { active: !c.active }), c.active ? 'Coupon paused' : 'Coupon activated'); }));
    main().querySelectorAll('[data-dc]').forEach((b) => b.addEventListener('click', () => { if (confirm(`Delete coupon ${b.dataset.dc}?`)) run(() => api('/coupons/' + b.dataset.dc, 'DELETE'), 'Coupon deleted'); }));
  }

  /* ---------- orders ---------- */
  function orders() {
    main().innerHTML = `<div class="top"><h1>Orders</h1></div>` + (D.orders.length ? D.orders.map((o) => `<article class="order">
      <header><div><b style="font-size:16px">${o.id}</b> <span class="muted">${new Date(o.createdAt).toLocaleString('en-IN')}</span></div>
        <select data-os="${o.id}" aria-label="Status for ${o.id}">${['new', 'confirmed', 'shipped', 'delivered', 'cancelled'].map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}</select></header>
      <div><b>${esc(o.customer.name)}</b> · <a href="tel:${esc(o.customer.phone)}">${esc(o.customer.phone)}</a><div class="muted" style="white-space:pre-line">${esc(o.customer.address)}</div></div>
      <div class="items">${o.items.map((l) => `${l.qty} × ${esc(l.name)} (${inr(l.price)})`).join('<br>')}</div>
      <div class="row" style="justify-content:space-between"><span class="muted">Subtotal ${inr(o.subtotal)}${o.discount ? ` · Coupon ${esc(o.coupon)} −${inr(o.discount)}` : ''} · Delivery ${o.delivery ? inr(o.delivery) : 'free'}</span><b style="font-size:17px">${inr(o.total)}</b></div></article>`).join('') : '<div class="panel"><p class="muted">No orders yet. New orders will appear here.</p></div>');
    main().querySelectorAll('[data-os]').forEach((s) => s.addEventListener('change', () => run(() => api('/orders/' + s.dataset.os, 'PUT', { status: s.value }), 'Order updated')));
  }

  /* ---------- settings ---------- */
  function settings() {
    const s = D.settings; let banners = JSON.parse(JSON.stringify(s.banners || []));
    const links = [['#/offers', 'Offers page'], ['#/all', 'All products'], ...D.categories.map((c) => ['#/cat/' + c.id, c.name])];
    main().innerHTML = `<div class="top"><h1>Settings</h1></div>
      <form id="sf"><div class="panel"><h2>Shop details</h2><div class="form">
        <div class="field"><label for="s_name">Shop name</label><input id="s_name" required value="${esc(s.shopName)}"></div>
        <div class="field"><label for="s_tag">Tagline</label><input id="s_tag" value="${esc(s.tagline)}"></div>
        <div class="field full"><label for="s_ann">Announcement bar (top of the site)</label><input id="s_ann" value="${esc(s.announcement)}"></div>
        <div class="field"><label for="s_ph">Phone</label><input id="s_ph" value="${esc(s.phone)}"></div>
        <div class="field"><label for="s_wa">WhatsApp number</label><input id="s_wa" placeholder="919876543210" value="${esc(s.whatsapp)}"><small>With country code, digits only</small></div>
        <div class="field full"><label for="s_ad">Shop address</label><input id="s_ad" value="${esc(s.address)}"></div>
        <div class="field"><label for="s_df">Delivery fee (₹)</label><input id="s_df" type="number" min="0" value="${s.deliveryFee}"></div>
        <div class="field"><label for="s_fd">Free delivery above (₹)</label><input id="s_fd" type="number" min="0" value="${s.freeDeliveryAbove}"></div>
      </div></div>
      <div class="panel"><h2>Home page banners</h2><div id="bn"></div><button type="button" class="btn ghost sm" id="bad" style="margin-top:10px">Add banner</button></div>
      <div class="panel"><h2>Categories</h2><div class="row" style="margin-bottom:10px">${D.categories.map((c) => `<span class="pill">${esc(c.name)} <a href="#" data-dcat="${c.id}" style="color:var(--chilli);text-decoration:none" aria-label="Delete ${esc(c.name)}">×</a></span>`).join('')}</div>
        <div class="row"><input id="nc" placeholder="New category name" style="height:40px;border:1.5px solid var(--line);border-radius:10px;padding:0 12px" aria-label="New category name"><button type="button" class="btn ghost" id="ncb">Add category</button></div></div>
      <div class="err" id="se"></div><button class="btn mango">Save settings</button></form>`;
    const drawB = () => {
      $('#bn').innerHTML = banners.map((b, i) => `<div class="banner-ed"><div class="prev">${b.image ? `<img src="${esc(b.image)}" alt="">` : ''}</div>
        <div class="form" style="gap:8px"><div class="field"><label>Title</label><input data-bf="title" data-i="${i}" value="${esc(b.title)}" maxlength="80"></div>
          <div class="field"><label>Subtitle</label><input data-bf="subtitle" data-i="${i}" value="${esc(b.subtitle)}" maxlength="120"></div>
          <div class="field"><label>Opens</label><select data-bf="link" data-i="${i}">${links.map(([v, n]) => `<option value="${v}" ${v === b.link ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></div>
          <div class="field"><label>Background photo</label><input type="file" accept="image/*" data-bi="${i}"></div>
          <div class="row"><button type="button" class="btn danger sm" data-bd="${i}">Remove banner</button>${b.image ? `<button type="button" class="btn ghost sm" data-bc="${i}">Remove photo</button>` : ''}</div></div></div>`).join('') || '<p class="muted">No banners. The home page will start with offers.</p>';
      $('#bn').querySelectorAll('[data-bf]').forEach((el) => el.addEventListener('input', () => { banners[+el.dataset.i][el.dataset.bf] = el.value; }));
      $('#bn').querySelectorAll('[data-bd]').forEach((b) => b.addEventListener('click', () => { banners.splice(+b.dataset.bd, 1); drawB(); }));
      $('#bn').querySelectorAll('[data-bc]').forEach((b) => b.addEventListener('click', () => { banners[+b.dataset.bc].image = ''; drawB(); }));
      $('#bn').querySelectorAll('[data-bi]').forEach((el) => el.addEventListener('change', async () => {
        try { banners[+el.dataset.bi].image = await uploadFile(el.files[0]); drawB(); } catch (e) { toast(e.message); }
      }));
    };
    drawB();
    $('#bad').addEventListener('click', () => { if (banners.length < 6) { banners.push({ title: 'New banner', subtitle: '', image: '', link: '#/offers' }); drawB(); } });
    $('#ncb').addEventListener('click', () => { const n = $('#nc').value.trim(); if (n) run(() => api('/categories', 'POST', { name: n }), 'Category added'); });
    main().querySelectorAll('[data-dcat]').forEach((a) => a.addEventListener('click', (e) => { e.preventDefault(); if (confirm('Delete this category?')) run(() => api('/categories/' + a.dataset.dcat, 'DELETE'), 'Category deleted'); }));
    $('#sf').addEventListener('submit', async (e) => {
      e.preventDefault();
      try {
        await api('/settings', 'PUT', { shopName: $('#s_name').value, tagline: $('#s_tag').value, announcement: $('#s_ann').value, phone: $('#s_ph').value, whatsapp: $('#s_wa').value, address: $('#s_ad').value, deliveryFee: +$('#s_df').value, freeDeliveryAbove: +$('#s_fd').value, banners });
        toast('Settings saved'); load();
      } catch (err) { $('#se').textContent = err.message; }
    });
  }

  token ? load() : loginView();
})();
