// Zero-dependency shop server: node server.js
// Storefront: http://localhost:3000   Admin: http://localhost:3000/admin/
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const UPLOADS = path.join(PUBLIC, 'uploads');
const DATA_DIR = path.join(ROOT, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

fs.mkdirSync(UPLOADS, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- storage ---------- */
const uid = (p) => p + crypto.randomBytes(4).toString('hex');

function seed() {
  const cats = [
    { id: 'electronics', name: 'Electronics' },
    { id: 'fashion', name: 'Fashion' },
    { id: 'home', name: 'Home & Kitchen' },
    { id: 'grocery', name: 'Grocery' },
    { id: 'beauty', name: 'Beauty' },
  ];
  const p = (name, brand, category, mrp, price, stock, extra = {}) => ({
    id: uid('p_'), name, brand, category, mrp, price, stock,
    description: 'Edit this demo product from the admin panel: change the photos, price and description.',
    highlights: ['Genuine product', 'Easy returns', 'Fast delivery'],
    offerText: '', images: [], featured: false, active: true,
    createdAt: new Date().toISOString(), ...extra,
  });
  return {
    settings: {
      shopName: 'My Shop',
      tagline: 'Everything you need, one trusted shop',
      announcement: 'Free delivery on orders above ₹999',
      whatsapp: '',
      phone: '',
      address: '',
      deliveryFee: 49,
      freeDeliveryAbove: 999,
      banners: [
        { title: 'Festive season sale', subtitle: 'Up to 40% off on top picks', image: '', link: '#/offers' },
        { title: 'New arrivals', subtitle: 'Fresh stock just landed in store', image: '', link: '#/all' },
      ],
    },
    categories: cats,
    products: [
      p('Wireless Bluetooth Earbuds', 'SoundMax', 'electronics', 2999, 1799, 25, { featured: true, offerText: 'Launch offer' }),
      p('Smart Fitness Band', 'FitPulse', 'electronics', 3499, 1999, 12, { featured: true }),
      p('Cotton Casual Shirt', 'UrbanLine', 'fashion', 1299, 799, 40),
      p('Non-stick Cookware Set', 'HomeChef', 'home', 2499, 1599, 8, { featured: true, offerText: 'Bank offer 5% off' }),
      p('Cold-pressed Coconut Oil 1L', 'Malabar Farms', 'grocery', 399, 349, 60),
      p('Herbal Face Wash', 'PureLeaf', 'beauty', 249, 189, 0),
      p('Backpack 30L', 'TrailPro', 'fashion', 1899, 999, 18),
      p('LED Desk Lamp', 'BrightHome', 'home', 999, 649, 30),
    ],
    coupons: [
      { code: 'WELCOME10', type: 'percent', value: 10, minOrder: 499, maxDiscount: 300, expiry: '', usageLimit: 0, used: 0, active: true },
      { code: 'FLAT100', type: 'flat', value: 100, minOrder: 1500, maxDiscount: 0, expiry: '', usageLimit: 0, used: 0, active: true },
    ],
    orders: [],
    orderSeq: 1000,
  };
}

let db;
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch { db = seed(); save(); }

function save() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}

/* ---------- helpers ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8', '.json': 'application/json',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.gif': 'image/gif', '.ico': 'image/x-icon',
};

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
const fail = (res, code, msg) => send(res, code, { error: msg });

function readJson(req, limit = 12 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('Request too large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => {
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new Error('Invalid JSON')); }
    });
    req.on('error', reject);
  });
}

const sessions = new Map(); // token -> expiry ms
function newSession() {
  const t = crypto.randomBytes(24).toString('hex');
  sessions.set(t, Date.now() + 12 * 3600 * 1000);
  return t;
}
function isAdmin(req) {
  const t = (req.headers.authorization || '').replace('Bearer ', '');
  const exp = sessions.get(t);
  if (!exp) return false;
  if (exp < Date.now()) { sessions.delete(t); return false; }
  return true;
}

const num = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const str = (v, max = 2000) => String(v ?? '').trim().slice(0, max);

function cleanProduct(b, existing = {}) {
  const mrp = Math.max(0, num(b.mrp, existing.mrp));
  let price = Math.max(0, num(b.price, existing.price ?? mrp));
  if (price > mrp) price = mrp;
  return {
    ...existing,
    name: str(b.name ?? existing.name, 200),
    brand: str(b.brand ?? existing.brand, 80),
    category: str(b.category ?? existing.category, 60),
    description: str(b.description ?? existing.description, 5000),
    highlights: (Array.isArray(b.highlights) ? b.highlights : existing.highlights || [])
      .map((h) => str(h, 160)).filter(Boolean).slice(0, 10),
    offerText: str(b.offerText ?? existing.offerText, 80),
    images: (Array.isArray(b.images) ? b.images : existing.images || [])
      .filter((u) => typeof u === 'string' && /^\/uploads\/[\w.-]+$/.test(u)).slice(0, 8),
    mrp, price,
    stock: Math.max(0, Math.floor(num(b.stock, existing.stock ?? 0))),
    featured: !!(b.featured ?? existing.featured),
    active: b.active === undefined ? existing.active ?? true : !!b.active,
  };
}

function couponDiscount(c, subtotal) {
  if (!c || !c.active) return { error: 'This coupon is not active' };
  if (c.expiry && new Date(c.expiry + 'T23:59:59') < new Date()) return { error: 'This coupon has expired' };
  if (c.usageLimit && c.used >= c.usageLimit) return { error: 'This coupon has reached its usage limit' };
  if (subtotal < c.minOrder) return { error: `Add items worth ₹${c.minOrder - subtotal} more to use this coupon` };
  let d = c.type === 'percent' ? Math.round((subtotal * c.value) / 100) : c.value;
  if (c.type === 'percent' && c.maxDiscount) d = Math.min(d, c.maxDiscount);
  return { discount: Math.min(d, subtotal) };
}
const findCoupon = (code) => db.coupons.find((c) => c.code === str(code, 40).toUpperCase());

function publicProduct(p) {
  const { createdAt, ...rest } = p; return { ...rest, createdAt };
}

/* ---------- API ---------- */
async function api(req, res, url) {
  const p = url.pathname;
  const m = req.method;

  // ----- public -----
  if (m === 'GET' && p === '/api/store') {
    return send(res, 200, {
      settings: db.settings,
      categories: db.categories,
      products: db.products.filter((x) => x.active).map(publicProduct),
    });
  }

  if (m === 'POST' && p === '/api/coupon/validate') {
    const b = await readJson(req);
    const c = findCoupon(b.code);
    if (!c) return fail(res, 404, 'Coupon code not found');
    const r = couponDiscount(c, num(b.subtotal));
    if (r.error) return fail(res, 400, r.error);
    return send(res, 200, { code: c.code, discount: r.discount });
  }

  if (m === 'POST' && p === '/api/orders') {
    const b = await readJson(req);
    const name = str(b.customer?.name, 100), phone = str(b.customer?.phone, 20), address = str(b.customer?.address, 500);
    if (!name || !/^[0-9+\s-]{8,15}$/.test(phone) || address.length < 8)
      return fail(res, 400, 'Enter your name, a valid phone number and full address');
    if (!Array.isArray(b.items) || !b.items.length) return fail(res, 400, 'Your cart is empty');

    const lines = [];
    for (const it of b.items) {
      const prod = db.products.find((x) => x.id === it.id && x.active);
      const qty = Math.floor(num(it.qty));
      if (!prod || qty < 1) return fail(res, 400, 'A product in your cart is no longer available');
      if (qty > prod.stock) return fail(res, 400, `Only ${prod.stock} left of ${prod.name}`);
      lines.push({ id: prod.id, name: prod.name, price: prod.price, qty, image: prod.images[0] || '' });
    }
    const subtotal = lines.reduce((s, l) => s + l.price * l.qty, 0);
    let discount = 0, couponCode = '';
    if (b.coupon) {
      const c = findCoupon(b.coupon);
      const r = couponDiscount(c, subtotal);
      if (r.error) return fail(res, 400, r.error);
      discount = r.discount; couponCode = c.code; c.used++;
    }
    const s = db.settings;
    const delivery = subtotal - discount >= s.freeDeliveryAbove ? 0 : s.deliveryFee;
    const order = {
      id: 'ORD' + ++db.orderSeq,
      customer: { name, phone, address },
      items: lines, subtotal, discount, coupon: couponCode, delivery,
      total: subtotal - discount + delivery,
      note: str(b.note, 300), status: 'new', createdAt: new Date().toISOString(),
    };
    for (const l of lines) db.products.find((x) => x.id === l.id).stock -= l.qty;
    db.orders.unshift(order);
    save();
    return send(res, 201, order);
  }

  // ----- admin auth -----
  if (m === 'POST' && p === '/api/admin/login') {
    const b = await readJson(req);
    const a = Buffer.from(str(b.password, 200)), z = Buffer.from(ADMIN_PASSWORD);
    const ok = a.length === z.length && crypto.timingSafeEqual(a, z);
    if (!ok) { await new Promise((r) => setTimeout(r, 600)); return fail(res, 401, 'Wrong password'); }
    return send(res, 200, { token: newSession() });
  }

  if (!p.startsWith('/api/admin/')) return fail(res, 404, 'Not found');
  if (!isAdmin(req)) return fail(res, 401, 'Please sign in again');

  // ----- admin data -----
  if (m === 'GET' && p === '/api/admin/data') {
    const paid = db.orders.filter((o) => o.status !== 'cancelled');
    return send(res, 200, {
      settings: db.settings, categories: db.categories, products: db.products,
      coupons: db.coupons, orders: db.orders,
      stats: {
        revenue: paid.reduce((s, o) => s + o.total, 0),
        orders: db.orders.length,
        newOrders: db.orders.filter((o) => o.status === 'new').length,
        products: db.products.length,
        lowStock: db.products.filter((x) => x.stock <= 5).length,
      },
    });
  }

  if (m === 'POST' && p === '/api/admin/upload') {
    const b = await readJson(req);
    const mt = /^data:(image\/(png|jpeg|webp|gif));base64,(.+)$/s.exec(b.data || '');
    if (!mt) return fail(res, 400, 'Upload a PNG, JPG, WebP or GIF image');
    const buf = Buffer.from(mt[3], 'base64');
    if (buf.length > 6 * 1024 * 1024) return fail(res, 400, 'Image is larger than 6 MB');
    const ext = { png: 'png', jpeg: 'jpg', webp: 'webp', gif: 'gif' }[mt[2]];
    const name = Date.now().toString(36) + crypto.randomBytes(3).toString('hex') + '.' + ext;
    fs.writeFileSync(path.join(UPLOADS, name), buf);
    return send(res, 201, { url: '/uploads/' + name });
  }

  // products
  if (m === 'POST' && p === '/api/admin/products') {
    const b = await readJson(req);
    const prod = cleanProduct(b, { id: uid('p_'), createdAt: new Date().toISOString() });
    if (!prod.name) return fail(res, 400, 'Product name is required');
    if (!prod.mrp) return fail(res, 400, 'Enter the MRP');
    db.products.unshift(prod); save();
    return send(res, 201, prod);
  }
  let r;
  if ((r = /^\/api\/admin\/products\/([\w-]+)$/.exec(p))) {
    const i = db.products.findIndex((x) => x.id === r[1]);
    if (i < 0) return fail(res, 404, 'Product not found');
    if (m === 'PUT') {
      const next = cleanProduct(await readJson(req), db.products[i]);
      if (!next.name) return fail(res, 400, 'Product name is required');
      db.products[i] = next; save(); return send(res, 200, next);
    }
    if (m === 'DELETE') { db.products.splice(i, 1); save(); return send(res, 200, { ok: true }); }
  }

  // bulk offer: set a discount % off MRP for a category (or everything)
  if (m === 'POST' && p === '/api/admin/offers/apply') {
    const b = await readJson(req);
    const pct = num(b.percent, -1);
    if (pct < 0 || pct > 90) return fail(res, 400, 'Enter a discount between 0 and 90');
    let n = 0;
    for (const x of db.products) {
      if (b.category && b.category !== 'all' && x.category !== b.category) continue;
      x.price = Math.round(x.mrp * (1 - pct / 100));
      if (b.offerText !== undefined) x.offerText = str(b.offerText, 80);
      n++;
    }
    save();
    return send(res, 200, { updated: n });
  }

  // categories
  if (m === 'POST' && p === '/api/admin/categories') {
    const b = await readJson(req);
    const name = str(b.name, 40);
    if (!name) return fail(res, 400, 'Enter a category name');
    const id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || uid('c_');
    if (db.categories.some((c) => c.id === id)) return fail(res, 400, 'That category already exists');
    db.categories.push({ id, name }); save();
    return send(res, 201, { id, name });
  }
  if ((r = /^\/api\/admin\/categories\/([\w-]+)$/.exec(p)) && m === 'DELETE') {
    if (db.products.some((x) => x.category === r[1]))
      return fail(res, 400, 'Move or delete the products in this category first');
    db.categories = db.categories.filter((c) => c.id !== r[1]); save();
    return send(res, 200, { ok: true });
  }

  // coupons
  const cleanCoupon = (b, ex = {}) => ({
    ...ex,
    code: str(b.code ?? ex.code, 40).toUpperCase().replace(/[^A-Z0-9_-]/g, ''),
    type: (b.type ?? ex.type) === 'flat' ? 'flat' : 'percent',
    value: Math.max(0, num(b.value, ex.value)),
    minOrder: Math.max(0, num(b.minOrder, ex.minOrder || 0)),
    maxDiscount: Math.max(0, num(b.maxDiscount, ex.maxDiscount || 0)),
    expiry: /^\d{4}-\d{2}-\d{2}$/.test(b.expiry ?? ex.expiry ?? '') ? (b.expiry ?? ex.expiry) : '',
    usageLimit: Math.max(0, Math.floor(num(b.usageLimit, ex.usageLimit || 0))),
    used: ex.used || 0,
    active: b.active === undefined ? ex.active ?? true : !!b.active,
  });
  if (m === 'POST' && p === '/api/admin/coupons') {
    const c = cleanCoupon(await readJson(req));
    if (!c.code) return fail(res, 400, 'Enter a coupon code');
    if (!c.value) return fail(res, 400, 'Enter the discount value');
    if (c.type === 'percent' && c.value > 100) return fail(res, 400, 'Percent discount cannot be above 100');
    if (db.coupons.some((x) => x.code === c.code)) return fail(res, 400, 'That coupon code already exists');
    db.coupons.unshift(c); save(); return send(res, 201, c);
  }
  if ((r = /^\/api\/admin\/coupons\/([A-Za-z0-9_-]+)$/.exec(p))) {
    const i = db.coupons.findIndex((x) => x.code === r[1]);
    if (i < 0) return fail(res, 404, 'Coupon not found');
    if (m === 'PUT') {
      const c = cleanCoupon(await readJson(req), db.coupons[i]);
      c.code = db.coupons[i].code;
      db.coupons[i] = c; save(); return send(res, 200, c);
    }
    if (m === 'DELETE') { db.coupons.splice(i, 1); save(); return send(res, 200, { ok: true }); }
  }

  // orders
  if ((r = /^\/api\/admin\/orders\/([\w-]+)$/.exec(p)) && m === 'PUT') {
    const o = db.orders.find((x) => x.id === r[1]);
    if (!o) return fail(res, 404, 'Order not found');
    const b = await readJson(req);
    if (!['new', 'confirmed', 'shipped', 'delivered', 'cancelled'].includes(b.status))
      return fail(res, 400, 'Unknown status');
    if (b.status === 'cancelled' && o.status !== 'cancelled')
      for (const l of o.items) { const pr = db.products.find((x) => x.id === l.id); if (pr) pr.stock += l.qty; }
    o.status = b.status; save();
    return send(res, 200, o);
  }

  // settings
  if (m === 'PUT' && p === '/api/admin/settings') {
    const b = await readJson(req);
    const s = db.settings;
    for (const k of ['shopName', 'tagline', 'announcement', 'whatsapp', 'phone', 'address'])
      if (b[k] !== undefined) s[k] = str(b[k], 300);
    if (b.deliveryFee !== undefined) s.deliveryFee = Math.max(0, num(b.deliveryFee));
    if (b.freeDeliveryAbove !== undefined) s.freeDeliveryAbove = Math.max(0, num(b.freeDeliveryAbove));
    if (Array.isArray(b.banners))
      s.banners = b.banners.slice(0, 6).map((x) => ({
        title: str(x.title, 80), subtitle: str(x.subtitle, 120),
        image: /^\/uploads\/[\w.-]+$/.test(x.image || '') ? x.image : '',
        link: /^#\/[\w\/-]*$/.test(x.link || '') ? x.link : '#/all',
      }));
    save(); return send(res, 200, s);
  }

  return fail(res, 404, 'Not found');
}

/* ---------- static files ---------- */
function serveStatic(req, res, url) {
  let rel = decodeURIComponent(url.pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(PUBLIC, rel));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Cache-Control': rel.startsWith('/uploads/') ? 'public, max-age=604800, immutable' : 'no-cache',
      'X-Content-Type-Options': 'nosniff',
    });
    res.end(buf);
  });
}

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
    if (url.pathname === '/admin') { res.writeHead(302, { Location: '/admin/' }); return res.end(); }
    serveStatic(req, res, url);
  } catch (e) {
    console.error(e);
    if (!res.headersSent) fail(res, 400, e.message || 'Something went wrong');
  }
}).listen(PORT, () => {
  console.log(`Shop running:  http://localhost:${PORT}`);
  console.log(`Admin panel:   http://localhost:${PORT}/admin/   (password: ${process.env.ADMIN_PASSWORD ? 'set via ADMIN_PASSWORD' : 'admin123 — change it!'})`);
});
