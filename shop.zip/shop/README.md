# My Shop: storefront + admin panel

No `npm install` needed. You only need Node.js 18 or newer (https://nodejs.org).

## Run it

    node server.js

- Shop:  http://localhost:3000
- Admin: http://localhost:3000/admin/   (default password: `admin123`)

Change the password and port before going live:

    # Mac / Linux
    ADMIN_PASSWORD=mySecret123 PORT=8080 node server.js
    # Windows (PowerShell)
    $env:ADMIN_PASSWORD="mySecret123"; node server.js

## What the admin can do

- **Products**: add, edit, delete, hide. MRP, selling price, stock, offer tag, highlights, description, up to 8 photos (first one is the main photo).
- **Offers**: set a % off for a whole category in one click, or set price per product.
- **Coupons**: percent or flat, minimum order, max discount, expiry date, usage limit, pause/delete.
- **Orders**: see customer details and items, change status (new, confirmed, shipped, delivered, cancelled). Cancelling puts the stock back.
- **Settings**: shop name, announcement bar, phone, WhatsApp number, delivery fee, free-delivery limit, home page banners, categories.

## What customers get

Search, categories, filters (price, discount, brand, in stock), sorting, product page with photo gallery, cart, coupon codes, cash-on-delivery checkout, WhatsApp button after ordering.

## Where data lives

- `data/db.json`: products, orders, coupons, settings. Back this file up.
- `public/uploads/`: product photos. Back this folder up too.

Prices, stock and coupons are always re-checked on the server when an order is placed.

## Putting it online

Any host that runs Node.js works (a VPS, Render, Railway, etc.). Set `ADMIN_PASSWORD`, keep `data/` and `public/uploads/` on persistent storage, and put it behind HTTPS.
